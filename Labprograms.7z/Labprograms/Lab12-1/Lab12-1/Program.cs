﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Lab12_1
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader Str = null;
            Console.WriteLine("enter filename to read:");
            string filename = Console.ReadLine();
            try
            {
                Str = new StreamReader(filename + ".txt");
                Console.WriteLine("contents of a file:\n");
                string store = Str.ReadToEnd();
                Console.WriteLine(store);
                Str.Close();
            }

            catch (FileNotFoundException)
            {
                Console.WriteLine("file not found");
            }
            Console.ReadLine();
        }
    }
    }

