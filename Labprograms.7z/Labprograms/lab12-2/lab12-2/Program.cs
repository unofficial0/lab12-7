﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace lab12_2
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine($"copy file operation");
            Console.WriteLine($"enter source filename:");
            string SourceFileName = Console.ReadLine();
            Console.WriteLine($"enter destination filename:");
            string destFileName = Console.ReadLine();
            try
            {
                File.Copy(SourceFileName, destFileName);
                Console.WriteLine($"copied successfully");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine($"file not found");
            }
            Console.ReadLine();
        }
    }
}
