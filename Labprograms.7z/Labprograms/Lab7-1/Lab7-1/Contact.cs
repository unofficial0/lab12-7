﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7_1
{
    class Contact
    {
        public int ContactId { get; set; }
        public String ContactName { get; set; }
        public string ContactNo { get; set; }
    }
}
